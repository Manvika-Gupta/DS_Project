#include<stdio.h>
#include<stdlib.h>
struct node
{
char data;
struct node* lptr;
struct node* rptr;
};

struct node* new_node(char);
void preorder(struct node *);
void inorder(struct node *);
void postorder(struct node *);

void main()
{
struct node* root,*t,*a,*b,*c,*d,*e,*f,*g;
char ch;
a=(struct node *)malloc(sizeof(struct node));
b=(struct node *)malloc(sizeof(struct node));
c=(struct node *)malloc(sizeof(struct node));
d=(struct node *)malloc(sizeof(struct node));
e=(struct node *)malloc(sizeof(struct node));
f=(struct node *)malloc(sizeof(struct node));
g=(struct node *)malloc(sizeof(struct node));
/*printf("Enter the data into the node:");
scanf("%c",ch);
ch=new_node(ch);
pri
*/
t=a;
/*
root=new_node('A');
root->lptr=new_node('B');
root->lptr->rptr=NULL;
root->rptr=new_node('D');
root->lptr->lptr=new_node('C');
root->lptr->lptr->lptr=NULL;
root->lptr->lptr->rptr=NULL;
root->rptr->lptr=new_node('E');
root->rptr->lptr->lptr=NULL;
root->rptr->rptr=new_node('G');
root->rptr->rptr->lptr=NULL;
root->rptr->rptr->rptr=NULL;
root->rptr->lptr->rptr=new_node('F');
root->rptr->lptr->rptr->lptr=NULL;
root->rptr->lptr->rptr->rptr=NULL;
*/

a->data='A';
a->lptr=b;
a->rptr=d;

b->data='B';
b->lptr=c;
b->rptr=NULL;

c->data='C';
c->lptr=NULL;
c->rptr=NULL;

d->data='D';
d->lptr=e;
d->rptr=g;

e->data='E';
e->lptr=NULL;
e->rptr=f;

g->data='G';
g->lptr=NULL;
g->rptr=NULL;

f->data='F';
f->lptr=NULL;
f->rptr=NULL;

printf("The Tree is \n");
printf("After preorder:\n");
preorder(t);
printf("\nAfter inorder:\n");
inorder(t);
printf("\nAfter postorder:\n");
postorder(t);
printf("\nDONE!");

}

struct node* new_node(char data)
{
    struct node *p; // node
    p = (struct node *)malloc(sizeof(struct node)); // allocating space to p
    p->data = data; // assinging data to p
    p->lptr = NULL; // making children NULL
    p->rptr = NULL;

    return(p); // returning the newly made node
}
void preorder(struct node *t)
{
if(t!=NULL)
{
printf("%c ",t->data);
if(t->lptr!=NULL)
{
preorder(t->lptr);
}
if(t->rptr!=NULL)
{
preorder(t->rptr);
}

}
else
{
printf("Empty");
}
}

void inorder(struct node *t)
{

if(t!=NULL)
{

if(t->lptr!=NULL)
{
inorder(t->lptr);
}
printf("%c ",t->data);

if(t->rptr!=NULL)
{
inorder(t->rptr);
}

}
else
{
printf("EMPTY");
}
}

void postorder(struct node*t)
{

if(t!=NULL)
{

if(t->lptr!=NULL)
{
postorder(t->lptr);
}
if(t->rptr!=NULL)
{
postorder(t->rptr);
}
printf("%c ",t->data);
}
else
{
printf("Empty");
}







}




