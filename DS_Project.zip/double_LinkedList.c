#include<stdio.h>
#include<stdlib.h>



struct node
{
int info;
struct node *lptr,*rptr;

};
void display(struct node *);
struct node* insert(struct node *);
struct node* delete(struct node *);
void main()
{

struct node *first,*second,*third,*list,*fourth;

first=(struct node*)malloc(sizeof(struct node));
second=(struct node*)malloc(sizeof(struct node));
third=(struct node*)malloc(sizeof(struct node));
list=(struct node*)malloc(sizeof(struct node));
fourth=(struct node*)malloc(sizeof(struct node));

int op;
first->info=1;
first->lptr=NULL;
first->rptr=second;
second->lptr=first;
second->info=2;
second->rptr=third;
third->lptr=second;
third->info=3;
third->rptr=fourth;
fourth->info=4;
fourth->rptr=NULL;

display(first);
printf("\nWhat do you want to do:\n1.Insert\n2.Delete\n");
scanf("%d",&op);
if(op==1)
{
list=insert(first);
printf("After Insertion\n");
display(list);
}
else
{
list=delete(first);
printf("After Deletion\n");
display(list);
}
}  


void display(struct node *first)
{
struct node *save;
save=first; //address of first node
printf("The list is ");
do
{

	printf("%d,",save->info);
	save=save->rptr;

}while(save!=NULL);

}


struct node* insert(struct node* first)
{
struct node *save,*new,*L,*R;
new=(struct node*)malloc(sizeof(struct node));
L=(struct node*)malloc(sizeof(struct node));
R=(struct node*)malloc(sizeof(struct node));
//L=first;
int x,y,m;



if(new==NULL)
{
printf("Overflow!");
return first;
}
else
{
save=first;
printf("\nWhere do you want to enter the element:\n1. Start\n2. End\n");
scanf("%d",&y);
printf("Enter the element you want to enter:");
scanf("%d",&x);
new->info=x;


//////////at the start

	if(y==1)
	{
	new->lptr=NULL;
	new->rptr=save;
	save->lptr=new;
	first=new;
	return first;
	}


///////////////////at the end
	else if(y==2)
	{
	while(save->rptr!=NULL)
	{	
	save=save->rptr;
	}
	new->lptr=save;
	new->rptr=NULL;
	save->rptr=new;
	return first;
	}
}


}

struct node* delete(struct node* first)
{
struct node *save,*pred,*new;
new=(struct node*)malloc(sizeof(struct node));

int del;

printf("\nEnter the element you want to delete:");
scanf("%d",&del);
save=first;
if(del!=first->info)
{
while(save!=NULL && save->info!=del)
{		
	save=save->rptr;
}

if(save->rptr!=NULL)
{
save->rptr->lptr=save->lptr;
}
if(save->lptr!=NULL)
{
save->lptr->rptr=save->rptr;
}
free(save);
}

else 
{
first=first->rptr;//first node deleted
}

return first;


//////////alternate method//////////


/*
printf("\nEnter the loc of element you want to delete:");
scanf("%d",&del);
save=first;
int i=1;
while(i<del && save!=NULL){
    
    save=save->rptr;
    i++;
}
if(i==1)
{
first=first->rptr;//first node deleted
}   
 
else if(save!=NULL)
{
    save->lptr->rptr=save->rptr;
    save->rptr->lptr=save->lptr;
    free(save);
}
return first;
*/





}



