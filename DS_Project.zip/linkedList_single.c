#include<stdio.h>
#include<stdlib.h>
struct node
{
int info;
struct node *link;
};
int count(struct node *);
void display(struct node *);
struct node *insertOrder(int,struct node*);
struct node *insertEnd(int,struct node*);
struct node *insertFirst(int,struct node*);
struct node* copy(struct node *);
void Quit();
void main()
{
int op,x;
struct node *first,*second,*third,*list;

first=(struct node*)malloc(sizeof(struct node));
second=(struct node*)malloc(sizeof(struct node));
third=(struct node*)malloc(sizeof(struct node));
list=(struct node*)malloc(sizeof(struct node));

first->info=1;
first->link=second;

second->info=2;
second->link=third;

third->info=8;
third->link=NULL;

printf("The list is:");
display(first);
while(op!=6)
{

printf("\nWhat do you want to do?\n1.Insert at start\n2.Insert at end\n3.Insert in order\n4.To display count of Elements\n5.To duplicate the linked list\n6.Quit\n");


scanf("%d",&op);
switch(op)
{


case 1:
printf("Enter element to enter: ");
scanf("%d",&x);
list=insertFirst(x,first);
printf("\nAfter insertion\n");
display(list);
break;

case 2:

printf("Enter element to enter: ");
scanf("%d",&x);
list=insertEnd(x,first);
printf("\nAfter insertion\n");
display(list);
break;

case 3:
printf("Enter element to enter: ");
scanf("%d",&x);
list=insertOrder(x,first);
printf("\nAfter insertion\n");
display(list);
break;

case 4:
printf("Number of Elements in Linked List: %d\n",count(first)+1);
break;

case 5:


printf("New Duplicate Linked list is:\n");
        struct node *dup = copy(first);
        display(dup);

break;
case 6:
Quit();
break;

default:
printf("Invalid input\n");

}//switch
}//while ends

}


void display(struct node *first)
{
struct node *save;
save=first; //address of first node
do
{

	printf("%d,",save->info);
	save=save->link;

}while(save!=NULL);

}

struct node *insertFirst(int x,struct node*first)
{

struct node *new;
new=(struct node*)malloc(sizeof(struct node));
if(new==NULL)
{
	printf("Overflow!");
	return first;
}
else
	{
		new->info=x;
		new->link=first;
		return new;
		
	}

}

struct node *insertEnd(int x,struct node*first)
{

struct node *new,*save;
new=(struct node*)malloc(sizeof(struct node));
save=(struct node*)malloc(sizeof(struct node));
if(new==NULL)
{
	printf("Overflow!");
	return first;
}
else
	{
		save=first;
			do{
				
			save=save->link;
			
			}while(save->link!=NULL);
		new->info=x;
		new->link=NULL;	
		save->link=new;
		return first;
		
	}

}



struct node *insertOrder(int x,struct node*first)
{

struct node *new,*save;
new=(struct node*)malloc(sizeof(struct node));
save=(struct node*)malloc(sizeof(struct node));

if(new==NULL)
{
	printf("Overflow!");
	return first;
}
save=first;
new->info=x;
if(new->info <= first->info)
	{
		new->link=first;
		return new;
	}
	
else 	

{	

	while(save->link!=NULL && new->info > save->link->info)
		{
			save=save->link;
		}
	
	new->link=save->link;
	save->link=new;
	return first;


}	

}


int count(struct node *head){
    struct node *save=head;
    int c=0;
    while(save->link!=NULL){
        c++;
        save = save->link;
    }
    return c;
}

struct node* copy(struct node *head){
    if(head==NULL){
        return NULL;
    }else{
        struct node *new;
        new = (struct node*)malloc(sizeof(struct node));
        new->info = head->info;
        new->link = copy(head->link);
        return new;
    }
}

void Quit()
{
printf("Thankyou\n");
}
