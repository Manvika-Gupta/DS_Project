#include<stdio.h>
#include<stdlib.h>

struct node
{
int data;
struct node * l,*r;
};

struct node *constructTree(int a[],int n);
struct node *orderedInsert(struct node *, int);
void inorder(struct node *);
struct node* getNode(int);
struct node* search(struct node *,int);
int getRightMin(struct node *);
struct node* delete(struct node *,int);
void main()
{

/*
int arr[]={4,7,12,3,6,8,1,5,10};
int n=sizeof(arr)/sizeof(arr[0]);
int x,y;
struct node * root;
root=(struct node *)malloc(sizeof(struct node));
*/
struct node * root;
root=(struct node *)malloc(sizeof(struct node));
int x,n,y;
printf("How many nodes? ");
scanf("%d",&n);
int a[n];
printf("Enter the list of nodes: ");
for(int i=0;i<n;i++)
{
//printf("-------------");
scanf("%d",&a[i]);
}

root=constructTree(a,n);
printf("\nThe inorder of the Binary Tree is ");
inorder(root);


printf("\nEnter the element you want to search? ");
scanf("%d",&x);
search(root,x);

printf("\nEnter the element you want to delete? ");
scanf("%d",&y);
root=delete(root,y);
printf("\nAfter deletion the tree is: ");
inorder(root);
}


struct node * constructTree(int arr[],int n)
{
if(n==0)
{
return NULL;
}
 struct node *root = NULL;
for(int i=0;i<n;i++)
{

	root=orderedInsert(root, arr[i]);

}
return root;

}


struct node *orderedInsert(struct node *root,int data)
{

	if(root==NULL)
	{
	root=getNode(data);
	return root;	
	}

if(data <= root->data)
{
root->l=orderedInsert(root->l,data);
}
else
{
root->r=orderedInsert(root->r,data);
}
return root;

}






struct node* getNode(int data)
{
    // Allocate memory
    struct node *newNode =
        (struct node*)malloc(sizeof(struct node));
     
    // put in the data   
    newNode->data = data;
    newNode->l = newNode->r = NULL;   
    return newNode;
}


void inorder(struct node *t)
{

if(t!=NULL)
{

if(t->l!=NULL)
{
inorder(t->l);
}
printf("%d ",t->data);

if(t->r!=NULL)
{
inorder(t->r);
}

}

}

struct node* search(struct node *root,int key)
{
  
  struct node *temp=root;
  printf("Visiting elements : ");
  while(temp->data!=key)
  {
    if(temp!=NULL)
    {
	
       printf("%d.. ",temp->data);
       if(temp->data>key)
       {
         temp=temp->l;
       }
       else
       {
          temp=temp->r;
       }
       if(temp==NULL)
       {
          printf("\nNode not found!\n");
          return NULL;
       }
    }
  }
  printf("\nNode found!\n");
  return temp;
}



int getRightMin(struct node *root)
 {
    struct node *temp = root;
    while(temp->l!=NULL)
    {
      temp = temp->l;
    }
    return temp->data;
 }
 
 struct node* delete(struct node *root,int key)
 {
   if(root==NULL)
   {
     return NULL;
   }
   
   if(key < root->data)
   {
     root->l = delete(root->l,key);
   }
   
   else if(key > root->data)
   {
     root->r = delete(root->r,key);
   }
   
   else
   {
     if(root->l==NULL && root->r==NULL)
     {
       free(root);
       return NULL;
     }
     else if(root->l==NULL)
     {
       struct node *temp = root->r;
       free(root);
       return temp;
     }
     else if(root->r==NULL)
     {
       struct node *temp = root->l;
       free(root);
       return temp;
     }
     
     else
     {
        int rightMin = getRightMin(root->r);
        root->data = rightMin;
        root->r = delete(root->r,rightMin);
     }
   }
   return root;
 }
