#include<stdio.h>
#include<stdlib.h>
//#include "cirList.h"

struct node
{
int info;
struct node *link;

};

void display(struct node*);
struct node *insertFirst(struct node *,struct node *);
struct node *insertEnd(struct node *,struct node *);
struct node *insertOrd(struct node *,struct node *);
struct node *delete(struct node *,struct node *);

void main()
{

struct node *first,*second,*last,*list,*third;
first=(struct node *)malloc(sizeof(struct node));
second=(struct node *)malloc(sizeof(struct node));
last=(struct node *)malloc(sizeof(struct node));
third=(struct node *)malloc(sizeof(struct node));
list=(struct node *)malloc(sizeof(struct node));
int op1,op2;

first->info=1;
first->link=second;
second->info=2;
second->link=third;
third->info=4;
third->link=last;
last->info=5;
last->link=first;

display(first);
printf("\nWhat do you want to do:\n1.Insert\n2.Delete\n");
scanf("%d",&op1);
if(op1==1)
{
printf("\nWhere do you want to insert:\n1.Start\n2.End\n3.In Order\n");
scanf("%d",&op2);
if(op2==1){
list=insertFirst(first,last);
}
else if(op2==2)
{
list=insertEnd(first,last);
}
else
{
list=insertOrd(first,last);
}
printf("After Insertion\n");
display(list);
}
else
{
list=delete(first,last);
printf("After Deletion\n");
display(list);
}


}


void display(struct node *first)
{
struct node *save;
save=(struct node *)malloc(sizeof(struct node));

if(first ==NULL)
{
printf("Empty");
}


else
{
save=first;
printf("List is: ");
	do
	{
		printf("%d,",save->info);
		save=save->link;

//printf("\naddress of first node is: %p ",first);

	}while(save!=first);

}
}



struct node *insertFirst(struct node *first,struct node *last)
{
int x;
struct node * new;
new=(struct node *)malloc(sizeof(struct node));
printf("\nEnter the Element you want to enter:");
scanf("%d",&x);

if(first==NULL)
{

printf("Empty");
return first;

}
else
{
	new->info=x;
	new->link=first;
	last->link=new;
	return new;
}

}



struct node *insertEnd(struct node *first,struct node *last)
{
int x;
struct node * new ,*save;
save=(struct node *)malloc(sizeof(struct node));
new=(struct node *)malloc(sizeof(struct node));
printf("\nEnter the Element you want to enter:");
scanf("%d",&x);

if(first==NULL)
{

printf("Empty");
return first;

}

else
{

	save=first;
	while(save!=last)
	{
		save=save->link;
	}

new->info=x;
save->link=new;
new->link=first;
return first;



}

}


struct node *insertOrd(struct node *first,struct node *last)
{
int x;
struct node * new ,*save;
save=(struct node *)malloc(sizeof(struct node));
new=(struct node *)malloc(sizeof(struct node));
printf("\nEnter the Element you want to enter:");
scanf("%d",&x);

if(first==NULL)
{

printf("Empty");
return first;

}
else
{
	save=first;
	new->info=x;
	if(first->info > new->info)
	{
		new->link=first;
		first->link=new;
		return first;
	}

	else
{


	do
	{
		save=save->link;

	}while(save!=last && save->link->info < new->info);
new->link=save->link;
save->link=new;
return first;
}
}

}

struct node *delete(struct node *first,struct node *last)
{
int del,i;
struct node *save,*pred;
save=(struct node*)malloc(sizeof(struct node));
pred=(struct node*)malloc(sizeof(struct node));
printf("Enter the element you want to delete:");
scanf("%d",&del);
save=first;

if(del!=first->info)
{
//for(i=0;i<=del;i++)
while(save->info!=del && save!=NULL)
{

	pred=save;
	save=save->link;

}
pred->link=save->link;
free(save);
//return first;
}

else{

first=first->link;//removes previous first
last->link=first;

}

return first;

}














